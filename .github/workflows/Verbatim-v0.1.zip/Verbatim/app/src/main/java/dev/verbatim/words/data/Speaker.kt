package dev.verbatim.words.data

import android.content.Context
import android.speech.tts.TextToSpeech
import java.util.Locale

/** Says words out loud with the phone's own text-to-speech. Works offline. */
object Speaker {
    private var tts: TextToSpeech? = null
    private var ready = false
    private var waiting: Pair<String, Float>? = null

    fun init(context: Context) {
        if (tts != null) return
        tts = TextToSpeech(context.applicationContext) { status ->
            ready = status == TextToSpeech.SUCCESS
            if (ready) waiting?.let { (text, rate) -> say(text, rate) }
            waiting = null
        }
    }

    /** Long-pressing ▶ say passes a slower [rate]. */
    fun say(text: String, rate: Float = Settings.speed.rate, locale: Locale = Settings.accent.locale) {
        val t = tts ?: return
        if (!ready) {
            waiting = text to rate
            return
        }
        t.language = locale
        t.setSpeechRate(rate)
        t.speak(text, TextToSpeech.QUEUE_FLUSH, null, "verbatim")
    }

    fun sayPortuguese(text: String) = say(text, Settings.speed.rate, Locale("pt", "PT"))

    fun shutdown() {
        tts?.shutdown()
        tts = null
        ready = false
    }
}
