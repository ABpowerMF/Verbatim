package dev.verbatim.words.data

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.time.LocalDate
import java.util.Locale

enum class VoiceAccent(val label: String, val locale: Locale) {
    US("US", Locale.US),
    UK("UK", Locale.UK),
    AU("Australian", Locale("en", "AU")),
}

enum class Speed(val label: String, val rate: Float) {
    SLOW("0.75x", 0.75f), NORMAL("1x", 1f), FAST("1.25x", 1.25f),
}

/** Everything the app remembers besides the look (that's in Appearance). */
object Settings {
    private fun prefs(context: Context) = context.getSharedPreferences("verbatim", Context.MODE_PRIVATE)
    private fun save(context: Context, block: SharedPreferences.Editor.() -> Unit) =
        prefs(context).edit().apply(block).apply()

    // ---- word
    var difficulty by mutableStateOf(Difficulty.MIX); private set
    var showSay by mutableStateOf(true); private set
    var showExample by mutableStateOf(true); private set
    var showPt by mutableStateOf(true); private set
    var showOrigin by mutableStateOf(true); private set
    var guessMode by mutableStateOf(false); private set

    // ---- voice
    var autoSpeak by mutableStateOf(false); private set
    var accent by mutableStateOf(VoiceAccent.US); private set
    var speed by mutableStateOf(Speed.NORMAL); private set

    // ---- reminder
    var reminderOn by mutableStateOf(false); private set
    var reminderHour by mutableStateOf(9); private set
    var reminderMinute by mutableStateOf(0); private set

    // ---- you
    var name by mutableStateOf(""); private set
    var haptics by mutableStateOf(true); private set

    // ---- progress
    var favorites by mutableStateOf(setOf<String>()); private set
    var todayDay by mutableStateOf(LocalDate.now().toEpochDay()); private set
    var firstDay by mutableStateOf(LocalDate.now().toEpochDay()); private set
    var streak by mutableStateOf(0); private set
    var bestStreak by mutableStateOf(0); private set
    private var lastOpen = -1L
    var quizRight by mutableStateOf(0); private set
    var quizTotal by mutableStateOf(0); private set
    var quizRun by mutableStateOf(0); private set
    var quizBestRun by mutableStateOf(0); private set

    val today: LocalDate get() = LocalDate.ofEpochDay(todayDay)

    fun load(context: Context) {
        val p = prefs(context)
        difficulty = Difficulty.entries.firstOrNull { it.name == p.getString("difficulty", null) } ?: Difficulty.MIX
        showSay = p.getBoolean("showSay", true)
        showExample = p.getBoolean("showExample", true)
        showPt = p.getBoolean("showPt", true)
        showOrigin = p.getBoolean("showOrigin", true)
        guessMode = p.getBoolean("guessMode", false)
        autoSpeak = p.getBoolean("autoSpeak", false)
        accent = VoiceAccent.entries.firstOrNull { it.name == p.getString("accent", null) } ?: VoiceAccent.US
        speed = Speed.entries.firstOrNull { it.name == p.getString("speed", null) } ?: Speed.NORMAL
        reminderOn = p.getBoolean("reminderOn", false)
        reminderHour = p.getInt("reminderHour", 9)
        reminderMinute = p.getInt("reminderMinute", 0)
        name = p.getString("name", "") ?: ""
        haptics = p.getBoolean("haptics", true)
        favorites = p.getStringSet("favorites", emptySet())?.toSet() ?: emptySet()
        todayDay = LocalDate.now().toEpochDay()
        firstDay = p.getLong("firstDay", todayDay)
        streak = p.getInt("streak", 0)
        bestStreak = p.getInt("bestStreak", 0)
        lastOpen = p.getLong("lastOpen", -1L)
        quizRight = p.getInt("quizRight", 0)
        quizTotal = p.getInt("quizTotal", 0)
        quizRun = p.getInt("quizRun", 0)
        quizBestRun = p.getInt("quizBestRun", 0)
    }

    /** Call when the app comes to the front. Moves to the new day and counts the streak. */
    fun markOpened(context: Context) {
        val now = LocalDate.now().toEpochDay()
        todayDay = now
        if (!prefs(context).contains("firstDay")) {
            firstDay = now
            save(context) { putLong("firstDay", now) }
        }
        if (lastOpen == now) return
        streak = if (lastOpen == now - 1) streak + 1 else 1
        if (streak > bestStreak) bestStreak = streak
        lastOpen = now
        save(context) {
            putInt("streak", streak)
            putInt("bestStreak", bestStreak)
            putLong("lastOpen", now)
        }
    }

    fun setDifficulty(context: Context, d: Difficulty) {
        difficulty = d; save(context) { putString("difficulty", d.name) }
    }
    fun setShowSay(context: Context, on: Boolean) {
        showSay = on; save(context) { putBoolean("showSay", on) }
    }
    fun setShowExample(context: Context, on: Boolean) {
        showExample = on; save(context) { putBoolean("showExample", on) }
    }
    fun setShowPt(context: Context, on: Boolean) {
        showPt = on; save(context) { putBoolean("showPt", on) }
    }
    fun setShowOrigin(context: Context, on: Boolean) {
        showOrigin = on; save(context) { putBoolean("showOrigin", on) }
    }
    fun setGuessMode(context: Context, on: Boolean) {
        guessMode = on; save(context) { putBoolean("guessMode", on) }
    }
    fun setAutoSpeak(context: Context, on: Boolean) {
        autoSpeak = on; save(context) { putBoolean("autoSpeak", on) }
    }
    fun setAccent(context: Context, a: VoiceAccent) {
        accent = a; save(context) { putString("accent", a.name) }
    }
    fun setSpeed(context: Context, s: Speed) {
        speed = s; save(context) { putString("speed", s.name) }
    }
    fun setReminderOn(context: Context, on: Boolean) {
        reminderOn = on; save(context) { putBoolean("reminderOn", on) }
    }
    fun setReminderTime(context: Context, hour: Int, minute: Int) {
        reminderHour = hour; reminderMinute = minute
        save(context) { putInt("reminderHour", hour); putInt("reminderMinute", minute) }
    }
    fun setName(context: Context, n: String) {
        name = n; save(context) { putString("name", n) }
    }
    fun setHaptics(context: Context, on: Boolean) {
        haptics = on; save(context) { putBoolean("haptics", on) }
    }

    fun isFavorite(word: String) = word in favorites

    fun toggleFavorite(context: Context, word: String) {
        favorites = if (word in favorites) favorites - word else favorites + word
        save(context) { putStringSet("favorites", HashSet(favorites)) }
    }

    fun recordAnswer(context: Context, right: Boolean) {
        quizTotal++
        if (right) {
            quizRight++
            quizRun++
            if (quizRun > quizBestRun) quizBestRun = quizRun
        } else {
            quizRun = 0
        }
        save(context) {
            putInt("quizRight", quizRight); putInt("quizTotal", quizTotal)
            putInt("quizRun", quizRun); putInt("quizBestRun", quizBestRun)
        }
    }

    fun resetQuiz(context: Context) {
        quizRight = 0; quizTotal = 0; quizRun = 0; quizBestRun = 0
        save(context) { putInt("quizRight", 0); putInt("quizTotal", 0); putInt("quizRun", 0); putInt("quizBestRun", 0) }
    }

    fun resetStreak(context: Context) {
        streak = 1; bestStreak = 1
        save(context) { putInt("streak", 1); putInt("bestStreak", 1) }
    }

    /** Days shown in the archive: from a week before first use up to today, newest first. */
    fun archiveDays(): List<LocalDate> {
        val start = firstDay - 7
        return (todayDay downTo start).map { LocalDate.ofEpochDay(it) }
    }
}
