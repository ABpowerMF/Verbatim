package dev.verbatim.words.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import androidx.compose.ui.graphics.toArgb
import dev.verbatim.words.MainActivity
import dev.verbatim.words.R
import dev.verbatim.words.data.Settings
import dev.verbatim.words.data.Words
import dev.verbatim.words.ui.theme.Appearance
import dev.verbatim.words.ui.theme.Mix

/** Home screen widget with today's word, painted in the app's current theme. */
class WordWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        ids.forEach { update(context, manager, it) }
    }

    companion object {
        fun refresh(context: Context) {
            val manager = AppWidgetManager.getInstance(context)
            val ids = manager.getAppWidgetIds(ComponentName(context, WordWidget::class.java))
            ids.forEach { update(context, manager, it) }
        }

        private fun update(context: Context, manager: AppWidgetManager, id: Int) {
            Settings.load(context)
            Appearance.load(context)
            val w = Words.today(context)
            val p = Mix.palette
            val v = RemoteViews(context.packageName, R.layout.widget_word)
            v.setInt(R.id.widget_root, "setBackgroundColor", p.ink.toArgb())
            v.setTextViewText(R.id.widget_label, "> word of the day")
            v.setTextColor(R.id.widget_label, p.tape.toArgb())
            v.setTextViewText(R.id.widget_word, w.word)
            v.setTextColor(R.id.widget_word, p.paper.toArgb())
            v.setTextViewText(R.id.widget_meta, listOf(w.pos, w.say).filter { it.isNotBlank() }.joinToString("  /  "))
            v.setTextColor(R.id.widget_meta, p.fog.toArgb())
            v.setTextViewText(R.id.widget_def, w.definition)
            v.setTextColor(R.id.widget_def, p.paper.toArgb())
            val open = PendingIntent.getActivity(
                context,
                0,
                Intent(context, MainActivity::class.java),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
            )
            v.setOnClickPendingIntent(R.id.widget_root, open)
            manager.updateAppWidget(id, v)
        }
    }
}
