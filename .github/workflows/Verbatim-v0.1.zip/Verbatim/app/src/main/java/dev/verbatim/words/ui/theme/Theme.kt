package dev.verbatim.words.ui.theme

import android.app.Activity
import android.content.Context
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import kotlin.math.max
import kotlin.math.min

/** The app's colours. Background, panels, highlights, lines, text, dim text, accent, errors. */
data class Palette(
    val ink: Color,
    val deep: Color,
    val raised: Color,
    val gap: Color,
    val paper: Color,
    val fog: Color,
    val tape: Color,
    val alert: Color = Color(0xFFFF5F56),
) {
    val isLight: Boolean get() = ink.luminance() > 0.5f

    companion object {
        /** Builds a full palette from the three colours people pick. */
        fun from(background: Color, text: Color, accent: Color) = Palette(
            ink = background,
            deep = lerp(background, text, 0.05f),
            raised = lerp(background, text, 0.10f),
            gap = lerp(background, text, 0.20f),
            paper = text,
            fog = lerp(background, text, 0.55f),
            tape = accent,
        )
    }
}

enum class ThemePreset(val label: String, val palette: Palette?) {
    TERMINAL("Terminal", Palette.from(Color(0xFF050805), Color(0xFFCFF5CF), Color(0xFF39FF6A))),
    MONO("Black & white", Palette.from(Color(0xFF000000), Color(0xFFF2F2F2), Color(0xFFFFFFFF))),
    PAPER("White & black", Palette.from(Color(0xFFFFFFFF), Color(0xFF111111), Color(0xFF000000))),
    GREEN_WHITE("Green & white", Palette.from(Color(0xFFFFFFFF), Color(0xFF102010), Color(0xFF16A34A))),
    AMBER("Amber", Palette.from(Color(0xFF0A0700), Color(0xFFFFE2A8), Color(0xFFFFB000))),
    NIGHT("Night drive", Palette.from(Color(0xFF16202E), Color(0xFFEAF0F7), Color(0xFFF2C14E))),
    INK("Old dictionary", Palette.from(Color(0xFFF3ECDC), Color(0xFF231A10), Color(0xFF9A2A1C))),
    CUSTOM("Custom", null),
}

/** Colours people can pick for a custom theme. */
val Swatches = listOf(
    0xFF000000, 0xFF050805, 0xFF0B1220, 0xFF16202E, 0xFF1E1E1E, 0xFF3A3A3A,
    0xFFFFFFFF, 0xFFF2F2F2, 0xFFF3ECDC, 0xFFFFF7E6, 0xFFCFF5CF, 0xFFEAF0F7,
    0xFF39FF6A, 0xFF16A34A, 0xFF00E5FF, 0xFF3B82F6, 0xFF8B5CF6, 0xFFFF4FD8,
    0xFFFF5F56, 0xFF9A2A1C, 0xFFFF8A00, 0xFFFFB000, 0xFFF2C14E, 0xFFFFEB3B,
).map { Color(it) }

enum class FontChoice(val label: String) {
    MONO("Monospace (terminal)"),
    CLEAN("Clean (sans)"),
    BOOK("Book (serif, dictionary-like)");

    val family: FontFamily
        get() = when (this) {
            MONO -> FontFamily.Monospace
            CLEAN -> FontFamily.SansSerif
            BOOK -> FontFamily.Serif
        }
}

enum class TextSize(val label: String, val scale: Float) {
    S("S", 0.9f), M("M", 1f), L("L", 1.12f), XL("XL", 1.25f),
}

/** Current look. Reading these from a composable redraws it when the theme changes. */
object Mix {
    var palette by mutableStateOf(ThemePreset.TERMINAL.palette!!)
    var font by mutableStateOf(FontChoice.MONO)
    var size by mutableStateOf(TextSize.M)
    var animations by mutableStateOf(true)
    var typewriter by mutableStateOf(true)
    var cursor by mutableStateOf(true)

    val Ink: Color get() = palette.ink         // background
    val Deep: Color get() = palette.deep       // panels
    val Raised: Color get() = palette.raised   // chips, selection
    val Gap: Color get() = palette.gap         // lines
    val Paper: Color get() = palette.paper     // main text
    val Fog: Color get() = palette.fog         // secondary text
    val Tape: Color get() = palette.tape       // accent
    val Alert: Color get() = palette.alert
}

private fun contrast(a: Color, b: Color): Float {
    val la = a.luminance() + 0.05f
    val lb = b.luminance() + 0.05f
    return max(la, lb) / min(la, lb)
}

/**
 * Keeps custom themes readable: text too close to the background becomes near-black or
 * near-white, and a faint accent is nudged towards the text colour until it stands out.
 * The picked colours stay saved; only what's drawn is adjusted.
 */
fun readable(p: Palette): Palette {
    val bg = p.ink
    var text = p.paper
    if (contrast(text, bg) < 4.5f) {
        text = if (bg.luminance() > 0.5f) Color(0xFF111111) else Color(0xFFF2F2F2)
    }
    var accent = p.tape
    var tries = 0
    while (contrast(accent, bg) < 2.4f && tries < 10) {
        accent = lerp(accent, text, 0.2f)
        tries++
    }
    return Palette.from(bg, text, accent)
}

/** Saves and restores the look. */
object Appearance {
    private fun prefs(context: Context) = context.getSharedPreferences("verbatim", Context.MODE_PRIVATE)

    var preset by mutableStateOf(ThemePreset.TERMINAL)
        private set
    var custom by mutableStateOf(ThemePreset.TERMINAL.palette!!)
        private set

    fun load(context: Context) {
        val p = prefs(context)
        preset = ThemePreset.entries.firstOrNull { it.name == p.getString("theme", null) } ?: ThemePreset.TERMINAL
        custom = Palette.from(
            Color(p.getInt("customBackground", Color(0xFF050805).toArgb())),
            Color(p.getInt("customText", Color(0xFFCFF5CF).toArgb())),
            Color(p.getInt("customAccent", Color(0xFF39FF6A).toArgb())),
        )
        Mix.font = FontChoice.entries.firstOrNull { it.name == p.getString("font", null) } ?: FontChoice.MONO
        Mix.size = TextSize.entries.firstOrNull { it.name == p.getString("textSize", null) } ?: TextSize.M
        Mix.animations = p.getBoolean("animations", true)
        Mix.typewriter = p.getBoolean("typewriter", true)
        Mix.cursor = p.getBoolean("cursor", true)
        apply()
    }

    fun choose(context: Context, preset: ThemePreset) {
        this.preset = preset
        prefs(context).edit().putString("theme", preset.name).apply()
        apply()
    }

    /** Changes one of the custom colours and switches to the custom theme. */
    fun setCustom(context: Context, background: Color? = null, text: Color? = null, accent: Color? = null) {
        val c = custom
        custom = Palette.from(background ?: c.ink, text ?: c.paper, accent ?: c.tape)
        prefs(context).edit()
            .putInt("customBackground", custom.ink.toArgb())
            .putInt("customText", custom.paper.toArgb())
            .putInt("customAccent", custom.tape.toArgb())
            .apply()
        choose(context, ThemePreset.CUSTOM)
    }

    fun setFont(context: Context, font: FontChoice) {
        Mix.font = font
        prefs(context).edit().putString("font", font.name).apply()
    }

    fun setSize(context: Context, size: TextSize) {
        Mix.size = size
        prefs(context).edit().putString("textSize", size.name).apply()
    }

    fun setAnimations(context: Context, on: Boolean) {
        Mix.animations = on
        prefs(context).edit().putBoolean("animations", on).apply()
    }

    fun setTypewriter(context: Context, on: Boolean) {
        Mix.typewriter = on
        prefs(context).edit().putBoolean("typewriter", on).apply()
    }

    fun setCursor(context: Context, on: Boolean) {
        Mix.cursor = on
        prefs(context).edit().putBoolean("cursor", on).apply()
    }

    private fun apply() {
        Mix.palette = preset.palette ?: readable(custom)
    }
}

/** Square corners, like a terminal window. */
val TermShape = RoundedCornerShape(0.dp)

/** Buttons look like terminal commands: [ save ] */
object Ui {
    fun btn(label: String) = "[ $label ]"
}

@Composable
fun VerbatimTheme(content: @Composable () -> Unit) {
    val p = Mix.palette
    val family = Mix.font.family
    val s = Mix.size.scale
    // Serif reads better with a little more line height.
    val lh = if (Mix.font == FontChoice.BOOK) 1.5f else 1.4f

    fun style(size: Float, weight: FontWeight = FontWeight.Normal) = TextStyle(
        fontFamily = family,
        fontWeight = weight,
        fontSize = (size * s).sp,
        lineHeight = (size * s * lh).sp,
    )

    val typography = Typography(
        displayLarge = TextStyle(
            fontFamily = family,
            fontWeight = FontWeight.Bold,
            fontSize = (40 * s).sp,
            lineHeight = (46 * s).sp,
        ),
        displaySmall = style(30f, FontWeight.Bold),
        headlineSmall = style(22f, FontWeight.Bold),
        titleLarge = style(19f, FontWeight.Bold),
        titleMedium = style(16f, FontWeight.Medium),
        bodyLarge = style(17f),
        bodyMedium = style(15f),
        bodySmall = style(13f),
        labelLarge = style(14f, FontWeight.Medium),
        labelMedium = style(12f),
        labelSmall = style(11f),
    )

    val scheme = if (p.isLight) {
        lightColorScheme(
            primary = p.tape, onPrimary = p.ink,
            background = p.ink, onBackground = p.paper,
            surface = p.deep, onSurface = p.paper,
            surfaceVariant = p.raised, onSurfaceVariant = p.fog,
            outline = p.gap, error = p.alert,
        )
    } else {
        darkColorScheme(
            primary = p.tape, onPrimary = p.ink,
            background = p.ink, onBackground = p.paper,
            surface = p.deep, onSurface = p.paper,
            surfaceVariant = p.raised, onSurfaceVariant = p.fog,
            outline = p.gap, error = p.alert,
        )
    }

    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window ?: return@SideEffect
            WindowCompat.getInsetsController(window, view).apply {
                isAppearanceLightStatusBars = p.isLight
                isAppearanceLightNavigationBars = p.isLight
            }
        }
    }

    MaterialTheme(
        colorScheme = scheme,
        typography = typography,
        shapes = Shapes(
            extraSmall = TermShape,
            small = TermShape,
            medium = TermShape,
            large = TermShape,
            extraLarge = TermShape,
        ),
        content = content,
    )
}
