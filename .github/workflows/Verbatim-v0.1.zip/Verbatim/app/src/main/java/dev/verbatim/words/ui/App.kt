package dev.verbatim.words.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.snap
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import dev.verbatim.words.data.Settings
import dev.verbatim.words.data.Word
import dev.verbatim.words.ui.theme.Mix
import java.time.LocalDate

enum class Tab(val label: String) { TODAY("today"), ARCHIVE("archive"), QUIZ("quiz"), SETTINGS("settings") }

/** A word opened from the archive or saved list. */
data class Opened(val word: Word, val date: LocalDate?)

@Composable
fun VerbatimApp(onAskNotifications: () -> Unit) {
    var tab by rememberSaveable { mutableStateOf(Tab.TODAY) }
    var opened by remember { mutableStateOf<Opened?>(null) }

    BackHandler(enabled = opened != null || tab != Tab.TODAY) {
        if (opened != null) opened = null else tab = Tab.TODAY
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(Mix.Ink)
            .systemBarsPadding(),
    ) {
        TopBar()
        Box(Modifier.weight(1f)) {
            Crossfade(
                targetState = tab to opened,
                animationSpec = if (Mix.animations) tween<Float>(220) else snap<Float>(),
                label = "screen",
            ) { (t, o) ->
                when {
                    o != null -> WordDetail(o.word, o.date) { opened = null }
                    t == Tab.TODAY -> TodayScreen()
                    t == Tab.ARCHIVE -> ArchiveScreen { w, d -> opened = Opened(w, d) }
                    t == Tab.QUIZ -> QuizScreen()
                    else -> SettingsScreen(onAskNotifications)
                }
            }
        }
        BottomTabs(tab) {
            tab = it
            opened = null
        }
    }
}

@Composable
private fun TopBar() {
    Column {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            val blink = rememberBlink()
            Text("> verbatim", color = Mix.Tape, style = MaterialTheme.typography.titleMedium)
            Text(
                "_",
                color = if (blink) Mix.Tape else Mix.Ink,
                style = MaterialTheme.typography.titleMedium,
            )
            Spacer(Modifier.weight(1f))
            val s = Settings.streak
            Text(
                if (s <= 1) "day 1" else "streak $s",
                color = Mix.Fog,
                style = MaterialTheme.typography.labelMedium,
            )
        }
        Line()
    }
}

@Composable
private fun BottomTabs(current: Tab, onPick: (Tab) -> Unit) {
    val buzz = rememberBuzz()
    Column(Modifier.background(Mix.Deep)) {
        Line()
        Row(Modifier.fillMaxWidth()) {
            Tab.entries.forEach { t ->
                val on = t == current
                Box(
                    Modifier
                        .weight(1f)
                        .clickable {
                            if (!on) buzz()
                            onPick(t)
                        }
                        .padding(vertical = 14.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(
                        if (on) "[${t.label}]" else t.label,
                        color = if (on) Mix.Tape else Mix.Fog,
                        style = MaterialTheme.typography.labelLarge,
                        maxLines = 1,
                        softWrap = false,
                    )
                }
            }
        }
    }
}
