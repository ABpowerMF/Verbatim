package dev.verbatim.words.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import dev.verbatim.words.data.Settings
import dev.verbatim.words.ui.theme.Mix
import dev.verbatim.words.ui.theme.TermShape
import dev.verbatim.words.ui.theme.Ui
import kotlinx.coroutines.delay

/** A terminal-style button: [ label ]. Long press is optional. */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun TermButton(
    label: String,
    modifier: Modifier = Modifier,
    color: Color = Mix.Tape,
    onLongClick: (() -> Unit)? = null,
    onClick: () -> Unit,
) {
    Box(
        modifier
            .border(1.dp, Mix.Gap, TermShape)
            .combinedClickable(onClick = onClick, onLongClick = onLongClick)
            .padding(horizontal = 10.dp, vertical = 9.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            Ui.btn(label),
            color = color,
            style = MaterialTheme.typography.labelLarge,
            maxLines = 1,
            softWrap = false,
        )
    }
}

/** Small heading inside a card or settings group, like a shell comment. */
@Composable
fun Label(text: String, modifier: Modifier = Modifier) {
    Text(
        "# $text",
        color = Mix.Fog,
        style = MaterialTheme.typography.labelMedium,
        modifier = modifier.padding(top = 18.dp, bottom = 4.dp),
    )
}

@Composable
fun SubLabel(text: String) {
    Text(
        text,
        color = Mix.Tape,
        style = MaterialTheme.typography.labelLarge,
        modifier = Modifier.padding(start = 20.dp, end = 20.dp, top = 16.dp, bottom = 4.dp),
    )
}

@Composable
fun Hint(text: String, color: Color = Mix.Fog) {
    Text(
        text,
        style = MaterialTheme.typography.bodySmall,
        color = color,
        modifier = Modifier.padding(horizontal = 20.dp, vertical = 4.dp),
    )
}

@Composable
fun Line(modifier: Modifier = Modifier) {
    Box(
        modifier
            .fillMaxWidth()
            .height(1.dp)
            .background(Mix.Gap),
    )
}

/** Radio-style choice: (•) Label */
@Composable
fun Choice(
    label: String,
    selected: Boolean,
    hint: String? = null,
    fontFamily: FontFamily? = null,
    onClick: () -> Unit,
) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 20.dp, vertical = 10.dp),
        verticalAlignment = Alignment.Top,
    ) {
        Text(
            if (selected) "(•)" else "( )",
            color = if (selected) Mix.Tape else Mix.Fog,
            style = MaterialTheme.typography.bodyMedium.copy(fontFamily = FontFamily.Monospace),
        )
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            val base = MaterialTheme.typography.bodyMedium
            Text(
                label,
                color = Mix.Paper,
                style = if (fontFamily != null) base.copy(fontFamily = fontFamily) else base,
            )
            if (hint != null) {
                Text(hint, color = Mix.Fog, style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

/** A switch that looks like a terminal flag: [ on ] / [off] */
@Composable
fun TermSwitch(checked: Boolean) {
    Box(
        Modifier
            .border(1.dp, if (checked) Mix.Tape else Mix.Gap, TermShape)
            .background(if (checked) Mix.Tape else Color.Transparent, TermShape)
            .padding(horizontal = 8.dp, vertical = 3.dp),
    ) {
        Text(
            if (checked) " on" else "off",
            color = if (checked) Mix.Ink else Mix.Fog,
            style = MaterialTheme.typography.labelLarge.copy(fontFamily = FontFamily.Monospace),
        )
    }
}

@Composable
fun ToggleRow(title: String, subtitle: String?, checked: Boolean, onChange: (Boolean) -> Unit) {
    val buzz = rememberBuzz()
    Row(
        Modifier
            .fillMaxWidth()
            .clickable {
                buzz()
                onChange(!checked)
            }
            .padding(horizontal = 20.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, color = Mix.Paper, style = MaterialTheme.typography.bodyMedium)
            if (subtitle != null) {
                Text(subtitle, color = Mix.Fog, style = MaterialTheme.typography.bodySmall)
            }
        }
        Spacer(Modifier.width(12.dp))
        TermSwitch(checked)
    }
}

/** A row of square number/size boxes, like Mixtape's "songs at the same time". */
@Composable
fun <T> BoxPicker(options: List<T>, selected: T, label: (T) -> String, onPick: (T) -> Unit) {
    Row(
        Modifier.padding(horizontal = 20.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        options.forEach { o ->
            val on = o == selected
            Box(
                Modifier
                    .size(width = 58.dp, height = 44.dp)
                    .border(1.dp, if (on) Mix.Tape else Mix.Gap, TermShape)
                    .background(if (on) Mix.Tape else Mix.Raised, TermShape)
                    .clickable { onPick(o) },
                contentAlignment = Alignment.Center,
            ) {
                Text(label(o), color = if (on) Mix.Ink else Mix.Paper, style = MaterialTheme.typography.titleMedium)
            }
        }
    }
}

/** Foldable settings section. The header shows the current choice: ▸ theme  Terminal */
@Composable
fun Fold(
    title: String,
    summary: String,
    open: Boolean,
    onToggle: () -> Unit,
    content: @Composable ColumnScope.() -> Unit,
) {
    Column(Modifier.fillMaxWidth()) {
        Row(
            Modifier
                .fillMaxWidth()
                .clickable(onClick = onToggle)
                .padding(horizontal = 20.dp, vertical = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(if (open) "▾ " else "▸ ", color = Mix.Tape, style = MaterialTheme.typography.titleMedium)
            Text(title, color = Mix.Paper, style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.width(12.dp))
            Text(
                summary,
                color = Mix.Fog,
                style = MaterialTheme.typography.bodySmall,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f),
            )
        }
        if (Mix.animations) {
            AnimatedVisibility(
                visible = open,
                enter = expandVertically() + fadeIn(),
                exit = shrinkVertically() + fadeOut(),
            ) {
                Column(Modifier.padding(bottom = 12.dp)) { content() }
            }
        } else if (open) {
            Column(Modifier.padding(bottom = 12.dp)) { content() }
        }
        Line()
    }
}

/** A light tap on the phone, if haptics are on. */
@Composable
fun rememberBuzz(): () -> Unit {
    val haptic = LocalHapticFeedback.current
    return remember(haptic) {
        { if (Settings.haptics) haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove) }
    }
}

/** Blinking terminal cursor state. Always "on" when the cursor setting is off. */
@Composable
fun rememberBlink(): Boolean {
    var on by remember { mutableStateOf(true) }
    val blinking = Mix.cursor
    LaunchedEffect(blinking) {
        on = true
        if (blinking) {
            while (true) {
                delay(530)
                on = !on
            }
        }
    }
    return on
}

/** Letters scramble, then settle into [target] from left to right. */
@Composable
fun ScrambleText(target: String, style: TextStyle, color: Color, modifier: Modifier = Modifier) {
    var text by remember { mutableStateOf(target) }
    LaunchedEffect(target) {
        if (!Mix.animations) {
            text = target
            return@LaunchedEffect
        }
        val noise = "abcdefghijklmnopqrstuvwxyz#%&*+=?"
        val frames = 16
        for (f in 0..frames) {
            val fixed = target.length * f / frames
            text = buildString {
                target.forEachIndexed { i, c -> append(if (i < fixed || c == ' ') c else noise.random()) }
            }
            delay(35)
        }
        text = target
    }
    Text(text, style = style, color = color, modifier = modifier)
}

/** The example sentence with the word itself picked out in the accent colour. */
fun highlight(example: String, word: String, color: Color): AnnotatedString {
    val stem = word.lowercase().take(maxOf(4, word.length - 3))
    val start = example.lowercase().indexOf(stem)
    return buildAnnotatedString {
        append(example)
        if (start >= 0) {
            var end = start + stem.length
            while (end < example.length && example[end].isLetter()) end++
            addStyle(SpanStyle(color = color, fontWeight = FontWeight.Bold), start, end)
        }
    }
}

fun shareText(context: Context, text: String) {
    val send = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(Intent.EXTRA_TEXT, text)
    }
    context.startActivity(Intent.createChooser(send, null))
}

fun copyText(context: Context, text: String) {
    val cm = context.getSystemService(ClipboardManager::class.java) ?: return
    cm.setPrimaryClip(ClipData.newPlainText("word", text))
    // Android 13+ shows its own "copied" bubble.
    if (Build.VERSION.SDK_INT < 33) Toast.makeText(context, "copied", Toast.LENGTH_SHORT).show()
}
