package dev.verbatim.words.data

import android.content.Context
import java.time.LocalDate
import kotlin.random.Random

/**
 * One entry from assets/words.txt. The file has one word per line:
 * word | part of speech | how to say it | rarity 1-3 | meaning | example | portuguese | origin
 */
data class Word(
    val word: String,
    val pos: String,
    val say: String,
    val level: Int,
    val definition: String,
    val example: String,
    val pt: String,
    val origin: String,
)

/** Which words can come up. 1 = handy, 2 = fancy, 3 = rare. */
enum class Difficulty(val label: String, val hint: String, val levels: Set<Int>) {
    MIX("Mix", "Everything, handy to rare", setOf(1, 2, 3)),
    GENTLE("Handy", "Words you'll actually get to use", setOf(1, 2)),
    BOLD("Fancy", "Showier words, no everyday ones", setOf(2, 3)),
    RARE("Rare only", "Strange, old and wonderful", setOf(3)),
}

object Words {
    // Fixed seed so everyone gets the same word on the same day.
    private const val SEED = 20260927
    @Volatile private var cache: List<Word>? = null

    fun all(context: Context): List<Word> {
        cache?.let { return it }
        val list = context.assets.open("words.txt").bufferedReader().useLines { lines ->
            lines.filter { it.isNotBlank() && !it.startsWith("#") }
                .mapNotNull { line ->
                    val c = line.split('|').map { it.trim() }
                    if (c.size < 8) null
                    else Word(c[0], c[1], c[2], c[3].toIntOrNull() ?: 2, c[4], c[5], c[6], c[7])
                }
                .toList()
        }
        cache = list
        return list
    }

    /** The words for this difficulty, in their fixed daily order. */
    fun pool(context: Context, difficulty: Difficulty): List<Word> {
        val all = all(context)
        val picked = all.filter { it.level in difficulty.levels }
        val base = if (picked.size >= 7) picked else all
        return base.shuffled(Random(SEED))
    }

    fun forDay(context: Context, day: LocalDate, difficulty: Difficulty = Settings.difficulty): Word {
        val p = pool(context, difficulty)
        val index = Math.floorMod(day.toEpochDay(), p.size.toLong()).toInt()
        return p[index]
    }

    fun today(context: Context): Word = forDay(context, LocalDate.now())

    fun find(context: Context, word: String): Word? = all(context).firstOrNull { it.word == word }

    /** A surprise word that isn't [except]. */
    fun random(context: Context, except: Word? = null): Word {
        val p = pool(context, Settings.difficulty)
        var w = p.random()
        var tries = 0
        while (w == except && tries < 5) {
            w = p.random()
            tries++
        }
        return w
    }
}
