package dev.verbatim.words.ui

import android.app.TimePickerDialog
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import dev.verbatim.words.BuildConfig
import dev.verbatim.words.data.Difficulty
import dev.verbatim.words.data.Settings
import dev.verbatim.words.data.Speaker
import dev.verbatim.words.data.Speed
import dev.verbatim.words.data.VoiceAccent
import dev.verbatim.words.data.Words
import dev.verbatim.words.notify.Reminder
import dev.verbatim.words.ui.theme.Appearance
import dev.verbatim.words.ui.theme.FontChoice
import dev.verbatim.words.ui.theme.Mix
import dev.verbatim.words.ui.theme.Palette
import dev.verbatim.words.ui.theme.Swatches
import dev.verbatim.words.ui.theme.TermShape
import dev.verbatim.words.ui.theme.TextSize
import dev.verbatim.words.ui.theme.ThemePreset
import dev.verbatim.words.widget.WordWidget
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale

@Composable
private fun ThemeRow(preset: ThemePreset, palette: Palette, selected: Boolean, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 20.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            if (selected) "(•)" else "( )",
            color = if (selected) Mix.Tape else Mix.Fog,
            style = MaterialTheme.typography.bodyMedium,
        )
        Spacer(Modifier.width(12.dp))
        // A tiny preview: background with a line of text and an accent block.
        Row(
            Modifier
                .border(1.dp, Mix.Gap, TermShape)
                .background(palette.ink)
                .padding(horizontal = 6.dp, vertical = 5.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(Modifier.size(width = 18.dp, height = 3.dp).background(palette.paper))
            Spacer(Modifier.width(4.dp))
            Box(Modifier.size(width = 6.dp, height = 10.dp).background(palette.tape))
        }
        Spacer(Modifier.width(12.dp))
        Text(preset.label, color = Mix.Paper, style = MaterialTheme.typography.bodyMedium)
    }
}

@Composable
private fun SwatchRow(label: String, current: Color, onPick: (Color) -> Unit) {
    Text(
        label,
        color = Mix.Paper,
        style = MaterialTheme.typography.bodyMedium,
        modifier = Modifier.padding(start = 20.dp, top = 8.dp, bottom = 6.dp),
    )
    LazyRow(
        contentPadding = PaddingValues(horizontal = 20.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        items(Swatches) { c ->
            val on = c.toArgb() == current.toArgb()
            Box(
                Modifier
                    .size(32.dp)
                    .border(if (on) 3.dp else 1.dp, if (on) Mix.Tape else Mix.Gap, TermShape)
                    .padding(if (on) 5.dp else 1.dp)
                    .background(c)
                    .clickable { onPick(c) },
            )
        }
    }
}

@Composable
private fun ValueRow(title: String, value: String, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 20.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(title, color = Mix.Paper, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
        Text(value, color = Mix.Tape, style = MaterialTheme.typography.titleMedium)
    }
}

/** A red button that needs two taps, so nothing gets wiped by accident. */
@Composable
private fun DangerButton(label: String, onConfirm: () -> Unit) {
    var armed by remember { mutableStateOf(false) }
    TermButton(
        if (armed) "tap again to $label" else label,
        modifier = Modifier.padding(horizontal = 20.dp, vertical = 4.dp),
        color = Mix.Alert,
    ) {
        if (armed) {
            onConfirm()
            armed = false
        } else {
            armed = true
        }
    }
}

@Composable
fun SettingsScreen(onAskNotifications: () -> Unit) {
    val context = LocalContext.current
    var open by remember { mutableStateOf(setOf<String>()) }
    fun toggle(key: String) {
        open = if (key in open) open - key else open + key
    }
    val time = "%02d:%02d".format(Settings.reminderHour, Settings.reminderMinute)

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
    ) {
        // ---------- Appearance ----------
        Fold("theme", Appearance.preset.label, "theme" in open, { toggle("theme") }) {
            ThemePreset.entries.forEach { preset ->
                ThemeRow(
                    preset,
                    preset.palette ?: Appearance.custom,
                    selected = Appearance.preset == preset,
                ) {
                    Appearance.choose(context, preset)
                    WordWidget.refresh(context)
                }
            }
        }

        Fold("custom colours", "pick three", "colours" in open, { toggle("colours") }) {
            SwatchRow("accent", Appearance.custom.tape) { Appearance.setCustom(context, accent = it) }
            SwatchRow("background", Appearance.custom.ink) { Appearance.setCustom(context, background = it) }
            SwatchRow("text", Appearance.custom.paper) { Appearance.setCustom(context, text = it) }
            Spacer(Modifier.height(6.dp))
            Hint("Picking a colour switches to the Custom theme. If two colours clash, the app quietly fixes the contrast so you can still read everything.")
        }

        Fold("font", Mix.font.label, "font" in open, { toggle("font") }) {
            FontChoice.entries.forEach { f ->
                Choice(f.label, selected = Mix.font == f, fontFamily = f.family) { Appearance.setFont(context, f) }
            }
            SubLabel("text size")
            BoxPicker(TextSize.entries, Mix.size, { it.label }) { Appearance.setSize(context, it) }
        }

        Fold("motion", if (Mix.animations) "on" else "off", "motion" in open, { toggle("motion") }) {
            ToggleRow("Animations", "Smooth screen changes, folding and the scramble effect", Mix.animations) {
                Appearance.setAnimations(context, it)
            }
            ToggleRow("Typewriter", "Today's word types itself out the first time you open the app", Mix.typewriter) {
                Appearance.setTypewriter(context, it)
            }
            ToggleRow("Blinking cursor", null, Mix.cursor) { Appearance.setCursor(context, it) }
        }

        // ---------- Words ----------
        Fold("words", Settings.difficulty.label, "words" in open, { toggle("words") }) {
            SubLabel("which words")
            Difficulty.entries.forEach { d ->
                Choice(d.label, selected = Settings.difficulty == d, hint = d.hint) {
                    Settings.setDifficulty(context, d)
                    WordWidget.refresh(context)
                }
            }
            Hint("Changing this also changes today's word and the archive.")
            SubLabel("show")
            ToggleRow("How to say it", null, Settings.showSay) { Settings.setShowSay(context, it) }
            ToggleRow("Example sentence", null, Settings.showExample) { Settings.setShowExample(context, it) }
            ToggleRow("Portuguese translation", null, Settings.showPt) { Settings.setShowPt(context, it) }
            ToggleRow("Origin", "Where the word comes from", Settings.showOrigin) { Settings.setShowOrigin(context, it) }
            SubLabel("challenge")
            ToggleRow("Guess mode", "Hide the meaning until you tap it", Settings.guessMode) {
                Settings.setGuessMode(context, it)
            }
        }

        // ---------- Voice ----------
        Fold("voice", "${Settings.accent.label}, ${Settings.speed.label}", "voice" in open, { toggle("voice") }) {
            ToggleRow("Say it on open", "Reads today's word out loud once a day", Settings.autoSpeak) {
                Settings.setAutoSpeak(context, it)
            }
            SubLabel("accent")
            VoiceAccent.entries.forEach { a ->
                Choice(a.label, selected = Settings.accent == a) { Settings.setAccent(context, a) }
            }
            SubLabel("speed")
            BoxPicker(Speed.entries, Settings.speed, { it.label }) { Settings.setSpeed(context, it) }
            Spacer(Modifier.height(6.dp))
            TermButton("▶ test voice", modifier = Modifier.padding(horizontal = 20.dp)) { Speaker.say("serendipity") }
            Hint("Long-press ▶ say on any word to hear it slowly. Uses your phone's own speech engine, so it works offline. If an accent sounds wrong, install that voice in Android's text-to-speech settings.")
        }

        // ---------- Reminder ----------
        Fold("reminder", if (Settings.reminderOn) time else "off", "reminder" in open, { toggle("reminder") }) {
            ToggleRow("Daily reminder", "A notification with the day's word", Settings.reminderOn) { on ->
                Settings.setReminderOn(context, on)
                if (on) onAskNotifications() else Reminder.schedule(context)
            }
            ValueRow("Time", time) {
                TimePickerDialog(
                    context,
                    { _, h, m ->
                        Settings.setReminderTime(context, h, m)
                        Reminder.schedule(context)
                    },
                    Settings.reminderHour,
                    Settings.reminderMinute,
                    true,
                ).show()
            }
            if (Settings.reminderOn && !Reminder.canNotify(context)) {
                Hint("Notifications are blocked for Verbatim. Allow them in Android settings.", Mix.Alert)
            }
            TermButton("send a test", modifier = Modifier.padding(horizontal = 20.dp, vertical = 6.dp)) {
                if (Reminder.canNotify(context)) Reminder.show(context) else onAskNotifications()
            }
            Hint("Tip: there's also a home screen widget. Long-press your home screen, tap Widgets, find Verbatim. It follows your theme.")
        }

        // ---------- You ----------
        Fold("you", Settings.name.ifBlank { "no name" }, "you" in open, { toggle("you") }) {
            Text(
                "Your name, for the greeting",
                color = Mix.Paper,
                style = MaterialTheme.typography.bodyMedium,
                modifier = Modifier.padding(start = 20.dp, top = 8.dp, bottom = 6.dp),
            )
            Box(
                Modifier
                    .padding(horizontal = 20.dp)
                    .fillMaxWidth()
                    .border(1.dp, Mix.Gap, TermShape)
                    .padding(12.dp),
            ) {
                BasicTextField(
                    value = Settings.name,
                    onValueChange = { Settings.setName(context, it.take(24)) },
                    singleLine = true,
                    textStyle = MaterialTheme.typography.bodyMedium.copy(color = Mix.Paper),
                    cursorBrush = SolidColor(Mix.Tape),
                    modifier = Modifier.fillMaxWidth(),
                )
            }
            Spacer(Modifier.height(6.dp))
            ToggleRow("Haptics", "A little buzz on taps and quiz answers", Settings.haptics) {
                Settings.setHaptics(context, it)
            }
        }

        // ---------- Progress ----------
        Fold("progress", "streak ${Settings.streak}", "progress" in open, { toggle("progress") }) {
            val since = LocalDate.ofEpochDay(Settings.firstDay)
                .format(DateTimeFormatter.ofPattern("d MMM yyyy", Locale.ENGLISH)).lowercase()
            val pct = if (Settings.quizTotal == 0) "-" else "${Settings.quizRight * 100 / Settings.quizTotal}%"
            Column(Modifier.padding(horizontal = 20.dp, vertical = 8.dp)) {
                listOf(
                    "streak" to "${Settings.streak} days",
                    "best streak" to "${Settings.bestStreak} days",
                    "saved words" to "${Settings.favorites.size}",
                    "quiz" to "${Settings.quizRight}/${Settings.quizTotal} ($pct)",
                    "best quiz run" to "${Settings.quizBestRun}",
                    "using since" to since,
                ).forEach { (k, v) ->
                    Row(Modifier.padding(vertical = 3.dp)) {
                        Text(k, color = Mix.Fog, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.width(130.dp))
                        Text(v, color = Mix.Paper, style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
            TermButton("share saved words", modifier = Modifier.padding(horizontal = 20.dp, vertical = 4.dp)) {
                val list = Settings.favorites.mapNotNull { Words.find(context, it) }.sortedBy { it.word.lowercase() }
                val text = if (list.isEmpty()) {
                    "No saved words yet."
                } else {
                    "My saved words (Verbatim):\n\n" + list.joinToString("\n") { "${it.word}: ${it.definition}" }
                }
                shareText(context, text)
            }
            DangerButton("reset quiz score") { Settings.resetQuiz(context) }
            DangerButton("reset streak") { Settings.resetStreak(context) }
        }

        // ---------- About ----------
        Fold("about", "v${BuildConfig.VERSION_NAME}", "about" in open, { toggle("about") }) {
            Text(
                "Verbatim v${BuildConfig.VERSION_NAME}\n" +
                    "${Words.all(context).size} words, all stored on the phone. No account, no ads, no internet needed.\n" +
                    "A new word every day at midnight. Everyone gets the same word on the same day.",
                color = Mix.Fog,
                style = MaterialTheme.typography.bodySmall,
                modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp),
            )
        }
        Spacer(Modifier.height(24.dp))
    }
}
