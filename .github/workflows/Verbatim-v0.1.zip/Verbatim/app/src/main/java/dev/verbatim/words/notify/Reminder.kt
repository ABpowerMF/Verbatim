package dev.verbatim.words.notify

import android.Manifest
import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import dev.verbatim.words.MainActivity
import dev.verbatim.words.R
import dev.verbatim.words.data.Settings
import dev.verbatim.words.data.Words
import dev.verbatim.words.widget.WordWidget
import java.time.LocalDateTime
import java.time.ZoneId

/** The daily "here's today's word" notification. */
object Reminder {
    private const val CHANNEL = "daily_word"

    fun canNotify(context: Context): Boolean =
        Build.VERSION.SDK_INT < 33 ||
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) ==
            PackageManager.PERMISSION_GRANTED

    /** Sets (or clears) the next alarm based on the saved time. */
    fun schedule(context: Context) {
        val am = context.getSystemService(AlarmManager::class.java) ?: return
        val pi = pending(context)
        am.cancel(pi)
        Settings.load(context)
        if (!Settings.reminderOn) return
        val now = LocalDateTime.now()
        var at = now.toLocalDate().atTime(Settings.reminderHour, Settings.reminderMinute)
        if (!at.isAfter(now)) at = at.plusDays(1)
        val millis = at.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
        am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, millis, pi)
    }

    private fun pending(context: Context): PendingIntent = PendingIntent.getBroadcast(
        context,
        1,
        Intent(context, ReminderReceiver::class.java),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
    )

    fun show(context: Context) {
        if (!canNotify(context)) return
        val nm = context.getSystemService(NotificationManager::class.java) ?: return
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Word of the day", NotificationManager.IMPORTANCE_DEFAULT).apply {
                description = "A daily nudge with today's word"
            },
        )
        Settings.load(context)
        val w = Words.today(context)
        val open = PendingIntent.getActivity(
            context,
            0,
            Intent(context, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val greeting = if (Settings.name.isBlank()) "> ${w.word}" else "> ${w.word}, ${Settings.name.lowercase()}"
        val n = NotificationCompat.Builder(context, CHANNEL)
            .setSmallIcon(R.drawable.ic_notify)
            .setContentTitle(greeting)
            .setContentText(w.definition)
            .setStyle(NotificationCompat.BigTextStyle().bigText("${w.pos}. ${w.definition}"))
            .setContentIntent(open)
            .setAutoCancel(true)
            .build()
        try {
            NotificationManagerCompat.from(context).notify(7, n)
        } catch (_: SecurityException) {
            // Permission was taken away; nothing to show.
        }
    }
}

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        Reminder.show(context)
        Reminder.schedule(context)
        WordWidget.refresh(context)
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) Reminder.schedule(context)
    }
}
