package dev.verbatim.words.ui

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import dev.verbatim.words.data.Settings
import dev.verbatim.words.data.Speaker
import dev.verbatim.words.data.Word
import dev.verbatim.words.data.Words
import dev.verbatim.words.ui.theme.Mix
import dev.verbatim.words.ui.theme.TermShape
import kotlinx.coroutines.delay
import java.time.LocalDate
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import java.util.Locale

private val dayFormat = DateTimeFormatter.ofPattern("EEE d MMM yyyy", Locale.ENGLISH)
private val shortFormat = DateTimeFormatter.ofPattern("dd MMM", Locale.ENGLISH)

/** Remembers, for this session, whether today's word already typed itself out / spoke. */
private object Session {
    var typedDay = -1L
    var spokeDay = -1L
}

fun wordAsText(w: Word): String = buildString {
    append(w.word)
    append(" (").append(w.pos).append(")\n")
    append(w.definition)
    if (w.example.isNotBlank()) append("\n\n\"").append(w.example).append("\"")
    append("\n\nword of the day, via Verbatim")
}

/** The full word card: word, how to say it, actions, meaning, example, Portuguese, origin. */
@Composable
fun WordView(word: Word, date: LocalDate?, isToday: Boolean) {
    val context = LocalContext.current
    val buzz = rememberBuzz()
    val day = date?.toEpochDay() ?: -1L
    val type = isToday && Mix.typewriter && Session.typedDay != day
    var shown by remember(word.word) { mutableIntStateOf(if (type) 0 else word.word.length) }
    var revealed by remember(word.word, Settings.guessMode) { mutableStateOf(!Settings.guessMode) }
    val blink = rememberBlink()

    LaunchedEffect(word.word) {
        if (shown < word.word.length) {
            delay(250)
            while (shown < word.word.length) {
                delay(75)
                shown++
            }
        }
        if (isToday) Session.typedDay = day
        if (isToday && Settings.autoSpeak && Session.spokeDay != day) {
            Session.spokeDay = day
            Speaker.say(word.word)
        }
    }

    Column(Modifier.padding(horizontal = 20.dp)) {
        val when_ = when {
            date == null -> "> saved word"
            isToday -> "> today, ${date.format(dayFormat).lowercase()}"
            else -> "> ${date.format(dayFormat).lowercase()}"
        }
        Text(when_, color = Mix.Fog, style = MaterialTheme.typography.labelMedium)
        Spacer(Modifier.height(10.dp))

        val big = if (word.word.length > 11) MaterialTheme.typography.displaySmall else MaterialTheme.typography.displayLarge
        Text(
            buildAnnotatedString {
                append(word.word.take(shown))
                if (isToday || shown < word.word.length) {
                    withStyle(SpanStyle(color = if (blink || !Mix.cursor) Mix.Tape else Color.Transparent)) {
                        append("▌")
                    }
                }
            },
            color = Mix.Paper,
            style = big,
        )

        val meta = buildString {
            append(word.pos)
            if (Settings.showSay && word.say.isNotBlank()) append("   /").append(word.say).append("/")
        }
        Text(meta, color = Mix.Fog, style = MaterialTheme.typography.bodyMedium)
        Text(
            "rarity " + "▮".repeat(word.level.coerceIn(1, 3)) + "▯".repeat(3 - word.level.coerceIn(1, 3)),
            color = Mix.Fog,
            style = MaterialTheme.typography.labelSmall,
        )

        Spacer(Modifier.height(14.dp))
        Row(
            Modifier.horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            TermButton("▶ say", onLongClick = {
                buzz()
                Speaker.say(word.word, 0.5f)
            }) {
                buzz()
                Speaker.say(word.word)
            }
            val fav = word.word in Settings.favorites
            TermButton(if (fav) "★ saved" else "☆ save") {
                buzz()
                Settings.toggleFavorite(context, word.word)
            }
            TermButton("share") { shareText(context, wordAsText(word)) }
            TermButton("copy") { copyText(context, wordAsText(word)) }
        }

        Label("meaning")
        if (!revealed) {
            Box(
                Modifier
                    .fillMaxWidth()
                    .border(1.dp, Mix.Gap, TermShape)
                    .clickable {
                        buzz()
                        revealed = true
                    }
                    .padding(16.dp),
            ) {
                Text("guess first, then tap to reveal", color = Mix.Fog, style = MaterialTheme.typography.bodyMedium)
            }
        } else {
            Text(word.definition, color = Mix.Paper, style = MaterialTheme.typography.bodyLarge)
        }

        if (Settings.showExample && word.example.isNotBlank()) {
            Label("example")
            Text(
                highlight(word.example, word.word, Mix.Tape),
                color = Mix.Paper,
                style = MaterialTheme.typography.bodyLarge.copy(fontStyle = FontStyle.Italic),
            )
        }

        if (Settings.showPt && word.pt.isNotBlank()) {
            Label("português")
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(word.pt, color = Mix.Paper, style = MaterialTheme.typography.bodyLarge, modifier = Modifier.weight(1f))
                Spacer(Modifier.width(8.dp))
                TermButton("▶ pt") { Speaker.sayPortuguese(word.pt.substringBefore("(").trim()) }
            }
        }

        if (Settings.showOrigin && word.origin.isNotBlank()) {
            Label("origin")
            Text(word.origin, color = Mix.Fog, style = MaterialTheme.typography.bodyMedium)
        }
    }
}

private fun greeting(name: String): String? {
    if (name.isBlank()) return null
    val h = LocalTime.now().hour
    val part = when (h) {
        in 5..11 -> "morning"
        in 12..17 -> "afternoon"
        in 18..22 -> "evening"
        else -> "up late"
    }
    val n = name.trim().lowercase()
    return if (part == "up late") "> up late, $n?" else "> $part, $n."
}

@Composable
fun TodayScreen() {
    val context = LocalContext.current
    val day = Settings.today
    val word = remember(day, Settings.difficulty) { Words.forDay(context, day) }
    var bonus by remember { mutableStateOf<Word?>(null) }
    val buzz = rememberBuzz()

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(vertical = 16.dp),
    ) {
        greeting(Settings.name)?.let {
            Text(it, color = Mix.Tape, style = MaterialTheme.typography.labelLarge, modifier = Modifier.padding(horizontal = 20.dp))
            Spacer(Modifier.height(6.dp))
        }
        WordView(word, day, isToday = true)

        Spacer(Modifier.height(28.dp))
        Line()
        Column(Modifier.padding(horizontal = 20.dp, vertical = 16.dp)) {
            Text(
                "one a day is the rule. bonus words don't count.",
                color = Mix.Fog,
                style = MaterialTheme.typography.bodySmall,
            )
            Spacer(Modifier.height(10.dp))
            TermButton(if (bonus == null) "roll a bonus word" else "roll again") {
                buzz()
                bonus = Words.random(context, bonus ?: word)
            }
            bonus?.let { b ->
                Spacer(Modifier.height(14.dp))
                Column(
                    Modifier
                        .fillMaxWidth()
                        .background(Mix.Deep, TermShape)
                        .border(1.dp, Mix.Gap, TermShape)
                        .padding(16.dp),
                ) {
                    ScrambleText(b.word, MaterialTheme.typography.headlineSmall, Mix.Paper)
                    Text(
                        b.pos + if (Settings.showSay && b.say.isNotBlank()) "   /${b.say}/" else "",
                        color = Mix.Fog,
                        style = MaterialTheme.typography.bodySmall,
                    )
                    Spacer(Modifier.height(8.dp))
                    Text(b.definition, color = Mix.Paper, style = MaterialTheme.typography.bodyMedium)
                    if (Settings.showPt && b.pt.isNotBlank()) {
                        Text("pt: ${b.pt}", color = Mix.Fog, style = MaterialTheme.typography.bodySmall)
                    }
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        TermButton("▶ say", onLongClick = { Speaker.say(b.word, 0.5f) }) { Speaker.say(b.word) }
                        val fav = b.word in Settings.favorites
                        TermButton(if (fav) "★ saved" else "☆ save") {
                            buzz()
                            Settings.toggleFavorite(context, b.word)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun WordDetail(word: Word, date: LocalDate?, onBack: () -> Unit) {
    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(vertical = 16.dp),
    ) {
        TermButton("← back", modifier = Modifier.padding(horizontal = 20.dp), onClick = onBack)
        Spacer(Modifier.height(18.dp))
        WordView(word, date, isToday = date == Settings.today)
        Spacer(Modifier.height(32.dp))
    }
}

@Composable
fun ArchiveScreen(onOpen: (Word, LocalDate?) -> Unit) {
    val context = LocalContext.current
    var query by rememberSaveable { mutableStateOf("") }
    var savedOnly by rememberSaveable { mutableStateOf(false) }
    val favorites = Settings.favorites
    val today = Settings.today

    val entries: List<Pair<Word, LocalDate?>> = remember(today, Settings.firstDay, Settings.difficulty, savedOnly, favorites) {
        if (savedOnly) {
            favorites.mapNotNull { Words.find(context, it) }.sortedBy { it.word.lowercase() }.map { it to null }
        } else {
            Settings.archiveDays().map { Words.forDay(context, it) to it }
        }
    }
    val shown = entries.filter { (w, _) ->
        query.isBlank() || w.word.contains(query.trim(), ignoreCase = true) ||
            w.definition.contains(query.trim(), ignoreCase = true)
    }

    Column(Modifier.fillMaxSize()) {
        Box(
            Modifier
                .padding(start = 20.dp, end = 20.dp, top = 16.dp)
                .fillMaxWidth()
                .border(1.dp, Mix.Gap, TermShape)
                .padding(horizontal = 12.dp, vertical = 12.dp),
        ) {
            BasicTextField(
                value = query,
                onValueChange = { query = it },
                singleLine = true,
                textStyle = MaterialTheme.typography.bodyMedium.copy(color = Mix.Paper),
                cursorBrush = SolidColor(Mix.Tape),
                modifier = Modifier.fillMaxWidth(),
                decorationBox = { inner ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("> ", color = Mix.Tape, style = MaterialTheme.typography.bodyMedium)
                        Box {
                            if (query.isEmpty()) {
                                Text("search words and meanings", color = Mix.Fog, style = MaterialTheme.typography.bodyMedium)
                            }
                            inner()
                        }
                    }
                },
            )
        }
        Row(
            Modifier.padding(horizontal = 20.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            TermButton("all", color = if (!savedOnly) Mix.Tape else Mix.Fog) { savedOnly = false }
            TermButton("★ saved ${favorites.size}", color = if (savedOnly) Mix.Tape else Mix.Fog) { savedOnly = true }
        }
        Line()

        if (shown.isEmpty()) {
            Text(
                when {
                    query.isNotBlank() -> "nothing matches \"${query.trim()}\"."
                    savedOnly -> "no saved words yet. tap ☆ save on any word to keep it here."
                    else -> "no words yet."
                },
                color = Mix.Fog,
                style = MaterialTheme.typography.bodyMedium,
                modifier = Modifier.padding(20.dp),
            )
        }

        LazyColumn(Modifier.fillMaxSize()) {
            items(shown, key = { (w, d) -> (d?.toEpochDay()?.toString() ?: "saved") + ":" + w.word }) { (w, d) ->
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clickable { onOpen(w, d) }
                        .padding(horizontal = 20.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    val isToday = d == today
                    Text(
                        when {
                            d == null -> "★"
                            isToday -> "today"
                            else -> d.format(shortFormat).lowercase()
                        },
                        color = if (isToday) Mix.Tape else Mix.Fog,
                        style = MaterialTheme.typography.labelMedium,
                        modifier = Modifier.width(64.dp),
                    )
                    Column(Modifier.weight(1f)) {
                        Text(w.word, color = Mix.Paper, style = MaterialTheme.typography.titleMedium)
                        Text(
                            w.definition,
                            color = Mix.Fog,
                            style = MaterialTheme.typography.bodySmall,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }
                    if (d != null && w.word in favorites) {
                        Spacer(Modifier.width(8.dp))
                        Text("★", color = Mix.Tape, style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
        }
    }
}

// ---------------------------------------------------------------- quiz

private enum class QuizMode { MEANING_TO_WORD, WORD_TO_MEANING }

private data class Question(val answer: Word, val options: List<Word>, val mode: QuizMode)

private fun makeQuestion(context: Context, previous: Word?): Question {
    // Quiz on words you've met: the archive plus anything you saved.
    val met = Settings.archiveDays().map { Words.forDay(context, it) } +
        Settings.favorites.mapNotNull { Words.find(context, it) }
    var pool = met.distinctBy { it.word }
    if (pool.size < 4) pool = Words.pool(context, Settings.difficulty)
    val choices = pool.filter { it.word != previous?.word }.ifEmpty { pool }
    val answer = choices.random()
    val others = pool.filter { it.word != answer.word }.shuffled().take(3).toMutableList()
    if (others.size < 3) {
        others += Words.all(context).filter { it.word != answer.word && it !in others }.shuffled().take(3 - others.size)
    }
    return Question(answer, (others + answer).shuffled(), QuizMode.entries.random())
}

@Composable
fun QuizScreen() {
    val context = LocalContext.current
    val buzz = rememberBuzz()
    var q by remember { mutableStateOf(makeQuestion(context, null)) }
    var picked by remember { mutableStateOf<Int?>(null) }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 16.dp),
    ) {
        val pct = if (Settings.quizTotal == 0) "" else "  (${Settings.quizRight * 100 / Settings.quizTotal}%)"
        Text(
            "> score ${Settings.quizRight}/${Settings.quizTotal}$pct   run ${Settings.quizRun}   best ${Settings.quizBestRun}",
            color = Mix.Fog,
            style = MaterialTheme.typography.labelMedium,
        )
        Spacer(Modifier.height(18.dp))

        val m2w = q.mode == QuizMode.MEANING_TO_WORD
        Text(
            if (m2w) "which word means this?" else "what does this word mean?",
            color = Mix.Tape,
            style = MaterialTheme.typography.labelLarge,
        )
        Spacer(Modifier.height(8.dp))
        if (m2w) {
            Text(q.answer.definition, color = Mix.Paper, style = MaterialTheme.typography.titleLarge)
        } else {
            Text(q.answer.word, color = Mix.Paper, style = MaterialTheme.typography.displaySmall)
            Text(q.answer.pos, color = Mix.Fog, style = MaterialTheme.typography.bodySmall)
        }
        Spacer(Modifier.height(18.dp))

        q.options.forEachIndexed { i, w ->
            val isAnswer = w.word == q.answer.word
            val p = picked
            val color = when {
                p == null -> Mix.Paper
                isAnswer -> Mix.Tape
                p == i -> Mix.Alert
                else -> Mix.Fog
            }
            val mark = when {
                p == null -> "${'a' + i})"
                isAnswer -> "✓ "
                p == i -> "✗ "
                else -> "  "
            }
            Row(
                Modifier
                    .fillMaxWidth()
                    .border(1.dp, if (p != null && isAnswer) Mix.Tape else Mix.Gap, TermShape)
                    .clickable(enabled = p == null) {
                        picked = i
                        buzz()
                        Settings.recordAnswer(context, isAnswer)
                    }
                    .padding(14.dp),
            ) {
                Text(mark, color = color, style = MaterialTheme.typography.bodyMedium)
                Spacer(Modifier.width(10.dp))
                Text(
                    if (m2w) w.word else w.definition,
                    color = color,
                    style = MaterialTheme.typography.bodyMedium,
                )
            }
            Spacer(Modifier.height(8.dp))
        }

        Spacer(Modifier.height(10.dp))
        val p = picked
        if (p == null) {
            TermButton("skip", color = Mix.Fog) { q = makeQuestion(context, q.answer) }
        } else {
            val right = q.options[p].word == q.answer.word
            Text(
                when {
                    right && Settings.quizRun >= 3 -> "correct. ${Settings.quizRun} in a row."
                    right -> "correct."
                    else -> "not quite. it's ${q.answer.word}."
                },
                color = if (right) Mix.Tape else Mix.Alert,
                style = MaterialTheme.typography.titleMedium,
            )
            if (q.answer.example.isNotBlank()) {
                Spacer(Modifier.height(6.dp))
                Text(
                    highlight(q.answer.example, q.answer.word, Mix.Tape),
                    color = Mix.Paper,
                    style = MaterialTheme.typography.bodyMedium.copy(fontStyle = FontStyle.Italic),
                )
            }
            Spacer(Modifier.height(14.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                TermButton("next") {
                    q = makeQuestion(context, q.answer)
                    picked = null
                }
                TermButton("▶ say") { Speaker.say(q.answer.word) }
            }
        }
    }
}
