package dev.verbatim.words

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import dev.verbatim.words.data.Settings
import dev.verbatim.words.data.Speaker
import dev.verbatim.words.notify.Reminder
import dev.verbatim.words.ui.VerbatimApp
import dev.verbatim.words.ui.theme.Appearance
import dev.verbatim.words.ui.theme.VerbatimTheme
import dev.verbatim.words.widget.WordWidget

class MainActivity : ComponentActivity() {

    private val askNotifications = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (!granted) Settings.setReminderOn(this, false)
        Reminder.schedule(this)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        Appearance.load(this)
        Settings.load(this)
        Settings.markOpened(this)
        Speaker.init(this)
        setContent {
            VerbatimTheme {
                VerbatimApp(onAskNotifications = ::askForNotifications)
            }
        }
    }

    private fun askForNotifications() {
        if (Build.VERSION.SDK_INT >= 33 && !Reminder.canNotify(this)) {
            askNotifications.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            Reminder.schedule(this)
        }
    }

    override fun onResume() {
        super.onResume()
        // Picks up a new day if the app was left open past midnight.
        Settings.markOpened(this)
    }

    override fun onStop() {
        super.onStop()
        WordWidget.refresh(this)
    }

    override fun onDestroy() {
        if (isFinishing) Speaker.shutdown()
        super.onDestroy()
    }
}
