# Verbatim

A word of the day, terminal style. Sister app to Mixtape.

- 365 hand-picked words (`app/src/main/assets/words.txt`), fully offline
- Same word for everyone on the same day; changes at midnight
- Archive, saved words, quiz, bonus words, streaks
- Themes, custom colours, fonts, text size, motion settings
- Text-to-speech (US / UK / Australian), Portuguese translations
- Daily reminder notification + home screen widget

Adding words: one per line in words.txt
`word | part of speech | how to say it | rarity 1-3 | meaning | example | portuguese | origin`

Build: upload the zip to the repo; `.github/workflows/build.yml` (copy of `build.yml` here) builds the APK into Releases.
